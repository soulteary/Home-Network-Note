<!-- PLEASE READ BEFORE DELETING

Bugs or Issues? Please create a new topic in our Discourse forum.
We are migrating all Drone repositories to Discourse for bug tracking.
New GitHub issues may be automatically deleted.

    https://community.harness.io/
    https://community.harness.io/c/bugs/17
    https://community.harness.io/c/ideas/11

Failing Builds? Please do not use GitHub issues for generic support
questions. Instead please use Stack Overflow:

    http://stackoverflow.com/questions/tagged/drone.io

-->
